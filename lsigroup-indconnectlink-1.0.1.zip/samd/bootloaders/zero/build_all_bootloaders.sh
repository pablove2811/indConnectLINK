#!/bin/bash -ex

BOARD_ID=indconnect_link NAME=indconnect_link make clean all

BOARD_ID=arduino_zero NAME=samd21_sam_ba make clean all

echo Done building bootloaders!
